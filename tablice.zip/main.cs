using System;

class MainClass {
  public static void Main (string[] args) {
    string[] dni_tygodnia = {"poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"};
    
    for (int i=0; i< dni_tygodnia.Length; i++)
    Console.WriteLine(dni_tygodnia[i]);

  }
}